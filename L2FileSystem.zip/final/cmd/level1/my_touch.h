#ifndef __TOUCH_H__
#define __TOUCH_H__
#include "../../util/util.h"

int my_touch(int argc, char *argv[]);
void run_touch(char *file);

#endif