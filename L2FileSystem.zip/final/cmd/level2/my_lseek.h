#ifndef __MY_LSEEK_H__
#define __MY_LSEEK_H__

#include "../../util/util.h"


int my_lseek(int argc, char*argv[]);
int run_lseek(int fd, int position);

#endif