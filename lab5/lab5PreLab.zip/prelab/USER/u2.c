#include "ucode.c"

int main()
{
  ubody("two");
}
