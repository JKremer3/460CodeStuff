#include "ucode.c"

int main()
{
  ubody("u1");
}
