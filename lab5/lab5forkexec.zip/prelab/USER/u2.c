#include "ucode.c"

int main()
{
  ubody("u2");
}
