#include "ucode.c"

main()
{
  ubody("u3");
}
